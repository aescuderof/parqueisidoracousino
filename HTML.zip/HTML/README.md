requires:

    1. yarn (https://yarnpkg.com);
    2. node.js (https://nodejs.org).

in project folder run cmd:

    1. install all dependencies: 'yarn';
    2. build + local server start: 'gulp dev';
    3. build only: 'gulp build'.